import React, {useCallback, useEffect, useState} from "react";
import { forwardRef } from 'react';

import { useSelector } from "react-redux";
import {useFirestoreConnect, isLoaded, isEmpty, useFirestore, useFirebase} from "react-redux-firebase";
import Table from "material-table";
import Details from "./Details";
import { ThemeProvider, createTheme } from '@mui/material';
import EditIcon from "@material-ui/icons/Edit";
import DeleteIcon from "@material-ui/icons/Delete";
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import Container from "@mui/material/Container";
import Box from "@mui/material/Box";
import TablePagination from '@mui/material/TablePagination';
import { getFirestore } from "firebase/firestore";


import {
    where,
    getCountFromServer,
    query,
    collection,
    CollectionReference,
    startAfter,
} from 'firebase/firestore';
import Ft from "../services";
import useFetchTasksCount from "./countHook";
import Pagination from "./Pagination";
const tableIcons = {
    Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
    Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
    Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
    Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
    DetailPanel: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
    Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
    Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
    Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
    FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
    LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
    NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
    PreviousPage: forwardRef((props, ref) => <ChevronLeft {...props} ref={ref} />),
    ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
    Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
    SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
    ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
    ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />)
};


export function Companies(props) {
    console.log("countcountcountcountcount", props);
    // Attach todos listener

    const [open, setOpen] = React.useState(false);
    const [currentRecord, setCurrentRecord] = useState({});
    const [currentPage, setCurrentPage] = useState(10);
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(10);
    const [count, setCount] = useState(0);

    const [queryt, setQueryt] = useState({
        collection: "mydata",
        limit: 10,
        orderBy: "wodate",

    });
    const [companies, setCompanies] = useState([]);

    const handleChangeRowsPerPage = (
        event,
    ) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };
    const handleDetailsClose = () => {
        setOpen(!open);
    };
   // const firebase = useFirebase();
    const defaultMaterialTheme = createTheme();
    const firestore = useFirestore();

    useFirestoreConnect(() => [queryt]);
    const snapshot = useFetchTasksCount(count);
    console.log("Line 14 ===> ", snapshot);

    if(typeof snapshot === "function" && count === 0) {
        snapshot().then((s) => {
            setCount(s._data.count)
        });
    }
    // useEffect(() => {
    //     const abc = () => {
    //         try {
    //             const firestores = getFirestore(window.db);
    //             // eslint-disable-next-line react-hooks/rules-of-hooks
    //             return useCallback(
    //                 () => {
    //
    //
    //                     const collectionRef = collection(
    //                         firestores,
    //                         "mydata"
    //                     );
    //
    //                     return getCountFromServer(
    //                         query(collectionRef)
    //                     );
    //
    //                 },
    //                 [firestores]
    //             );
    //         } catch (e) {
    //             console.log("Line 37 ===> ", e);
    //             return 0;
    //         }
    //     }
    //     const s = abc();
    //     console.log("Line 129 ===> ", s);
    // }, []);
    useEffect(() => {

        const data = [
            {"owneraddress":"47423 W Medina Dr","generalctst":"","stdate":"","udate":"05/06/2022","generalct":"pacific Habitat Inc","generalctphone":"","architectemail":"","code":"","generalctcity":"","adate":"05/06/2022","owner":"Yahn Family Trust","link":"","generalctaddress":"","generalctemail":"","ownerzip":"92260","wodate":"05/05/2022","appxvalue":"Less than $350000","joblocation":"47423 W Medina Dr","typework":"SFD addition/remodel","createdAt":"Timestamp(seconds=1651867317","zone":"nanoseconds=937000000)","city":"Desert","citycodes":"Palm Desert","ownercity":"PD","generalctzip":"Palm Desert","jobstatus":"","ownerphone":"Applied","architectphone":"","architect":"","ownerst":"","field32":"California"}
            ,
            {"owneraddress":"775 West Chino Canyon Rd","generalctst":"California","stdate":"","udate":"10/01/2021","generalct":"o2 Architecture","generalctphone":"(760) 778-8165","architectemail":"","code":"","generalctcity":"Palm Springs","adate":"10/01/2021","owner":"o2 architecture c/0 Michael Flannery","link":"","generalctaddress":"1089 N Palm Canyon Dr","generalctemail":"","ownerzip":"92262","wodate":"10/01/2021","appxvalue":"Greater than $350000","joblocation":"775 West Chino Canyon Rd","typework":"SFD - 5,711 sq ft","createdAt":"Timestamp(seconds=1633106738","zone":"nanoseconds=295000000)","city":"Desert","citycodes":"Palm Springs","ownercity":"PS","generalctzip":"Palm Springs","jobstatus":"92262","ownerphone":"Issued","architectphone":"(760) 778-8165","architect":"(760) 778-8165","ownerst":"o2 Architecture","field32":"California"}
            ,
            {"owneraddress":"47224 Crystal Loop","generalctst":"","stdate":"","udate":"11/09/2021","generalct":"n/a","generalctphone":"","architectemail":"","code":"623-151-008","generalctcity":"","adate":"11/09/2021","owner":"Home Re-configurer","link":"","generalctaddress":"","generalctemail":"","ownerzip":"92210","wodate":"11/10/2021","appxvalue":"Greater than $350000","joblocation":"47224 Crystal Loop","typework":"SFD - re-configure/remodel","createdAt":"Timestamp(seconds=1636514591","zone":"nanoseconds=737000000)","city":"Desert","citycodes":"Indian Wells","ownercity":"IW","generalctzip":"Indian Wells","jobstatus":"","ownerphone":"Issued","architectphone":"","architect":"","ownerst":"","field32":"California"}
            ,
            {"owneraddress":"1001 Bridgeway #711","generalctst":"","stdate":"","udate":"10/17/2022","generalct":"https://www.blackpoint.com/     ","generalctphone":"","architectemail":"","code":"600-030-018","generalctcity":"","adate":"10/17/2022","owner":"City of La Quinta and Blackpoint Properties","link":"","generalctaddress":"","generalctemail":"","ownerzip":"94965","wodate":"10/14/2022","appxvalue":"Greater than $350000","joblocation":"N.E. Corner Dune Palms and Highway 111","typework":"Commercial Parcel negotiating","createdAt":"Timestamp(seconds=1666039476","zone":"nanoseconds=319000000)","city":"Desert","citycodes":"La Quinta","ownercity":"LQ","generalctzip":"Sausalito","jobstatus":"","ownerphone":"Entitlements","architectphone":"(707) 559-3330","architect":"","ownerst":"","field32":"California"}
            ,
            {"owneraddress":"","generalctst":"CA","stdate":"","udate":"10/28/2021","generalct":"davisReed Construction Inc.","generalctphone":"760-777-1440","architectemail":"","code":"","generalctcity":"Palm Desert","adate":"10/28/2021","owner":"","link":"","generalctaddress":"44875 Deep Canyon Rd","generalctemail":"","ownerzip":"","wodate":"10/27/2021","appxvalue":"Greater than $350000","joblocation":"3130 N Indian Canyon Dr Bldg 4","typework":"Community  Building - Clubhouse","createdAt":"Timestamp(seconds=1635466603","zone":"nanoseconds=773000000)","city":"Desert","citycodes":"Palm Springs","ownercity":"PS","generalctzip":"","jobstatus":"92211","ownerphone":"Issued","architectphone":"","architect":"","ownerst":"","field32":""}
            ,
            {"owneraddress":"","generalctst":"CA","stdate":"","udate":"10/28/2021","generalct":"davisReed Construction Inc.","generalctphone":"760-777-1440","architectemail":"","code":"","generalctcity":"Palm Desert","adate":"10/28/2021","owner":"Applicant","link":"","generalctaddress":"44875 Deep Canyon Rd","generalctemail":"","ownerzip":"","wodate":"10/27/2021","appxvalue":"Greater than $350000","joblocation":"3130 N Indian Canyon Dr  Bldgs 1 thru 12","typework":"(11) 4-6 or 8 two story apartment building","createdAt":"Timestamp(seconds=1635463140","zone":"nanoseconds=536000000)","city":"Desert","citycodes":"Palm Springs","ownercity":"PS","generalctzip":"","jobstatus":"92211","ownerphone":"Issued","architectphone":"(707) 759-6043","architect":"760-777-1440","ownerst":"davisReed Construction Inc.","field32":""}
            ,
            {"owneraddress":"1345 Ladera Circle","generalctst":"","stdate":"","udate":"04/08/2022","generalct":"c/o the Canavan Group","generalctphone":"(415) 609-0267","architectemail":"","code":"","generalctcity":"","adate":"04/08/2022","owner":"Home remodeler","link":"","generalctaddress":"","generalctemail":"","ownerzip":"92262","wodate":"04/07/2022","appxvalue":"Greater than $350000","joblocation":"1345 Ladera Circle","typework":"Partial demo then rebuild/remodel SFD","createdAt":"Timestamp(seconds=1649441252","zone":"nanoseconds=118000000)","city":"Desert","citycodes":"Palm Springs","ownercity":"PS","generalctzip":"Palm Springs","jobstatus":"","ownerphone":"Issued","architectphone":"","architect":"","ownerst":"","field32":"California"}
            ,
            {"owneraddress":"61125 Goodwood Dr","generalctst":"","stdate":"","udate":"06/01/2022","generalct":"c/o Wendell Burnett Architects","generalctphone":"(602) 395-1091","architectemail":"","code":"","generalctcity":"","adate":"06/01/2022","owner":"Home Builder","link":"","generalctaddress":"","generalctemail":"","ownerzip":"92274","wodate":"05/27/2022","appxvalue":"Greater than $350000","joblocation":"61125 Goodwood Dr     \"Thermal Club\"","typework":"SFD \"3 story\"","createdAt":"Timestamp(seconds=1654105065","zone":"nanoseconds=778000000)","city":"Desert","citycodes":"County","ownercity":"CT","generalctzip":"Thermal","jobstatus":"","ownerphone":"Applied","architectphone":"","architect":"","ownerst":"","field32":"California"}
            ,
            {"owneraddress":"","generalctst":"","stdate":"","udate":"07/13/2022","generalct":"c/o Wendell Burnerre Architects/Kent McClure","generalctphone":"(602) 395-1091","architectemail":"","code":"","generalctcity":"","adate":"07/13/2022","owner":"","link":"","generalctaddress":"","generalctemail":"","ownerzip":"","wodate":"07/13/2022","appxvalue":"Greater than $350000","joblocation":"61125 Goodwood Dr","typework":"Merging (2) SFD lots for duplex","createdAt":"Timestamp(seconds=1657736499","zone":"nanoseconds=199000000)","city":"Desert","citycodes":"County","ownercity":"CT","generalctzip":"","jobstatus":"","ownerphone":"Issued","architectphone":"","architect":"","ownerst":"","field32":""}
            ,
            {"owneraddress":"73700 Dinah Shore Dr #303","generalctst":"","stdate":"","udate":"07/04/2021","generalct":"c/o Wade Ritchie, Designer","generalctphone":"(760) 831-6659","architectemail":"","code":"","generalctcity":"","adate":"07/04/2021","owner":"Fitz-Henry Wiefels/Lori Wiefels","link":"","generalctaddress":"","generalctemail":"","ownerzip":"92211","wodate":"07/02/2021","appxvalue":"Less than $350000","joblocation":"73700 Dinah Shore Dr #303","typework":"Commercial - T.I","createdAt":"Timestamp(seconds=1625440873","zone":"nanoseconds=854000000)","city":"Desert","citycodes":"Palm Desert","ownercity":"PD","generalctzip":"Palm Desert","jobstatus":"","ownerphone":"Applied","architectphone":"","architect":"(760) 323-2263","ownerst":"Wendel Veith","field32":"California"}
            ,
            {"owneraddress":"","generalctst":"California","stdate":"","udate":"01/10/2022","generalct":"c/o Ventura Engineering Inland","generalctphone":"","architectemail":"","code":"","generalctcity":"Temecula","adate":"01/10/2022","owner":"","link":"","generalctaddress":"27393 Ynez","generalctemail":"","ownerzip":"","wodate":"01/11/2022","appxvalue":"Greater than $350000","joblocation":"46161 Anza","typework":"SFD","createdAt":"Timestamp(seconds=1641839801","zone":"nanoseconds=771000000)","city":"Desert","citycodes":"Coachella","ownercity":"CO","generalctzip":"","jobstatus":"92591","ownerphone":"Issued","architectphone":"","architect":"","ownerst":"","field32":""}
            ,
            {"owneraddress":"","generalctst":"","stdate":"","udate":"01/10/2022","generalct":"c/o Ventura Egineering/Wilfredo","generalctphone":"(951) 239-1144","architectemail":"","code":"","generalctcity":"","adate":"01/10/2022","owner":"","link":"","generalctaddress":"","generalctemail":"","ownerzip":"","wodate":"01/11/2022","appxvalue":"Greater than $350000","joblocation":"46161 Anza Rd ( Anza  Area)","typework":"SFD Grading","createdAt":"Timestamp(seconds=1641839969","zone":"nanoseconds=217000000)","city":"Desert","citycodes":"County","ownercity":"CT","generalctzip":"","jobstatus":"","ownerphone":"Issued","architectphone":"","architect":"","ownerst":"","field32":""}
            ,
            {"owneraddress":"","generalctst":"","stdate":"","udate":"04/15/2022","generalct":"c/o Thomas Tabler","generalctphone":"(210) 889-7019","architectemail":"","code":"","generalctcity":"","adate":"04/15/2022","owner":"","link":"","generalctaddress":"","generalctemail":"","ownerzip":"","wodate":"04/14/2022","appxvalue":"Greater than $350000","joblocation":"57795 Big Horn Dr  \"Mountain Center area\"","typework":"SFD","createdAt":"Timestamp(seconds=1650053560","zone":"nanoseconds=304000000)","city":"Desert","citycodes":"County","ownercity":"CT","generalctzip":"","jobstatus":"","ownerphone":"Issued","architectphone":"","architect":"","ownerst":"","field32":""}
            ,
            {"owneraddress":"1100 Glendon Ave #2100","generalctst":"","stdate":"","udate":"04/12/2021","generalct":"c/o The Altum Group, Engineering/Consulting","generalctphone":"","architectemail":"https://bit.ly/3g6Fe0b","code":"","generalctcity":"","adate":"04/12/2021","owner":"Oakview Group","link":"","generalctaddress":"","generalctemail":"scollins@oakviewgroup.com","ownerzip":"90024","wodate":"04/15/2021","appxvalue":"Greater than $350000","joblocation":"E of I-10 E. of Cook St, N of 38th","typework":"273,000 S Q Ft Arena + 35,000 Sq Ft Hockey Bldg","createdAt":"Timestamp(seconds=1618262359","zone":"nanoseconds=696000000)","city":"Desert","citycodes":"County","ownercity":"CT","generalctzip":"Los Angeles","jobstatus":"","ownerphone":"Entitlements","architectphone":"(310) 954-4809","architect":"","ownerst":"","field32":"California"}
            ,
            {"owneraddress":"74876 42nd Ave","generalctst":"","stdate":"","udate":"07/13/2022","generalct":"c/o Taylor Bond","generalctphone":"","architectemail":"","code":"","generalctcity":"","adate":"07/13/2022","owner":"Motive Infrastructure Solutions","link":"","generalctaddress":"","generalctemail":"","ownerzip":"92201","wodate":"07/13/2022","appxvalue":"Greater than $350000","joblocation":"74876 42nd Ave","typework":"Commercial T.I","createdAt":"Timestamp(seconds=1657733985","zone":"nanoseconds=764000000)","city":"Desert","citycodes":"County","ownercity":"CT","generalctzip":"Indio","jobstatus":"","ownerphone":"Issued","architectphone":"","architect":"","ownerst":"","field32":"California"}
            ,
            {"owneraddress":"","generalctst":"","stdate":"","udate":"07/13/2022","generalct":"c/o Studio Linea Inc/Michael Hanes","generalctphone":"(760) 899-3368","architectemail":"","code":"","generalctcity":"","adate":"07/13/2022","owner":"Thermal Club","link":"","generalctaddress":"","generalctemail":"","ownerzip":"","wodate":"07/13/2022","appxvalue":"Greater than $350000","joblocation":"86813 Newton Way  \"Thermal Area\" ","typework":"SFD","createdAt":"Timestamp(seconds=1657730992","zone":"nanoseconds=241000000)","city":"Desert","citycodes":"County","ownercity":"CT","generalctzip":"","jobstatus":"","ownerphone":"Issued","architectphone":"","architect":"","ownerst":"","field32":""}
            ,
            {"owneraddress":"80860 Vista Lazo","generalctst":"","stdate":"","udate":"07/10/2021","generalct":"c/o Studio Linea Inc","generalctphone":"(310) 645-4800","architectemail":"","code":"","generalctcity":"Manhattan Beach","adate":"07/10/2021","owner":"VUJACIC/VENDETTi","link":"","generalctaddress":"1705 Meadows Ave","generalctemail":"","ownerzip":"92253","wodate":"07/09/2021","appxvalue":"Less than $350000","joblocation":"80860 VISTA LAZO","typework":"SFD - 7,875 Sq Ft","createdAt":"Timestamp(seconds=1625941107","zone":"nanoseconds=143000000)","city":"Desert","citycodes":"La Quinta","ownercity":"LQ","generalctzip":"La Quinta","jobstatus":"","ownerphone":"Issued","architectphone":"","architect":"","ownerst":"","field32":"California"}
            ,
            {"owneraddress":"53425 Via Dona","generalctst":"California","stdate":"","udate":"10/04/2021","generalct":"c/o Studio Linea Inc","generalctphone":"(760) 423-6561","architectemail":"","code":"","generalctcity":"Indian Wells","adate":"10/04/2021","owner":"Karrels Residence","link":"","generalctaddress":"77165 Delgado Dr","generalctemail":"","ownerzip":"92253","wodate":"10/01/2021","appxvalue":"Greater than $350000","joblocation":"53425   Via Dona","typework":"SFD - 4,475 sq ft","createdAt":"Timestamp(seconds=1633392923","zone":"nanoseconds=486000000)","city":"Desert","citycodes":"La Quinta","ownercity":"LQ","generalctzip":"La Quinta","jobstatus":"92210","ownerphone":"Issued","architectphone":"","architect":"","ownerst":"Studio Linea","field32":"California"}
            ,
            {"owneraddress":"","generalctst":"California","stdate":"","udate":"07/10/2021","generalct":"c/o Studio Linea Inc","generalctphone":"(760) 423-6561","architectemail":"","code":"","generalctcity":"Palm Desert","adate":"07/10/2021","owner":"","link":"","generalctaddress":"77622 Country Club Dr Suite N","generalctemail":"","ownerzip":"","wodate":"07/09/2021","appxvalue":"Less than $350000","joblocation":"53425  Via Dona","typework":"SFD","createdAt":"Timestamp(seconds=1625949587","zone":"nanoseconds=446000000)","city":"Desert","citycodes":"La Quinta","ownercity":"LQ","generalctzip":"","jobstatus":"92211","ownerphone":"Issued","architectphone":"","architect":"","ownerst":"","field32":""}
            ,
            {"owneraddress":"","generalctst":"","stdate":"","udate":"06/01/2022","generalct":"c/o Studio 2007 / Yasman Y Flores","generalctphone":"(760) 984-8764","architectemail":"","code":"","generalctcity":"","adate":"06/01/2022","owner":"","link":"","generalctaddress":"","generalctemail":"","ownerzip":"","wodate":"05/27/2022","appxvalue":"Less than $350000","joblocation":"89562 63rd  Ave","typework":"SFD","createdAt":"Timestamp(seconds=1654105599","zone":"nanoseconds=938000000)","city":"Desert","citycodes":"County","ownercity":"CT","generalctzip":"","jobstatus":"","ownerphone":"Issued","architectphone":"","architect":"","ownerst":"","field32":""}
        ];
        for(let i= 0; i<30; i++) {
            const itemUpdates = data[i] || data[0];
          //  itemUpdates.zone = "A";
            //firestore.add({ collection: 'mydata' }, itemUpdates);

        }
        //
        // data.forEach(async(itemUpdates) => {
        //     itemUpdates.zone = "A";
        //     await firestore.add({ collection: 'users' }, itemUpdates);
        // })
    }, []);
    const records = useSelector(state => state.firestore.ordered.mydata) || [];
    console.log("Line 94 ====> ", records);
    // Show a message while todos are loading
    // if (!isLoaded(companies) ) {
    //     return "Loading";
    // }

    // Show a message if there are no todos dd
    // if (isEmpty(companies)) {
    //     return "Company list is empty";
    // }
    useEffect(() => {
        setCompanies(records);
        console.log("Line 160 ===> ", records);
    },[JSON.stringify(records)]);
    const handleChangePage = (
        event,
        newPage,
    ) => {
        alert(newPage)
        const lastVisible = companies[companies.length -1];
        console.log("last", lastVisible,  startAfter(lastVisible));
        const next = {
            collection: "mydata",
            limit: 2,
            orderBy: "wodate",
            startAt: 29 ,
        }
        setPage(newPage);
        //
        // // const next = { collection: "users", queryParams: [ `startAt=${(rowsPerPage * newPage) + 1}`, 'limitToFirst=10' ] };
        //
        setCompanies([]);
        setTimeout(() => {
            setQueryt(next);
        }, 1000);
    };
    const columnss = [
        { title: "OK", field: "OK" },
        { title: "ID", field: "id" },
        { title: "name", field: "name" },

    ];
    console.debug(companies);

    const columns = [
        {
            "title": "Zone",
            "field": "zone"
        },
        {
            "title": "City Codes",
            "field": "citycodes"
        },
        {
            "title": "City",
            "field": "city"
        },
        {
            "title": "Appx Value",
            "field": "appxvalue"
        },
        {
            "title": "Type Work",
            "field": "typework"
        },
        {
            "title": "Owner",
            "field": "owner"
        },
        {
            "title": "Owner Phone",
            "field": "ownerphone"
        },
        {
            "title": "Owner Address",
            "field": "owneraddress"
        },
        {
            "title": "Owner City",
            "field": "ownercity"
        },
        {
            "title": "Owner St",
            "field": "ownerst"
        },
        {
            "title": "Zip",
            "field": "ownerzip"
        },
        {
            "title": "General Ct",
            "field": "generalct"
        },
        {
            "title": "General Ct Phone",
            "field": "generalctphone"
        },
        {
            "title": "General Ct Address",
            "field": "generalctaddress"
        },
        {
            "title": "General Ct Email",
            "field": "generalctemail"
        },
        {
            "title": "General Ct City",
            "field": "generalctcity"
        },
        {
            "title": "General Ct St",
            "field": "generalctst"
        },
        {
            "title": "General Ct Zip",
            "field": "generalctzip"
        },
        {
            "title": "Architect",
            "field": "architect"
        },
        {
            "title": "Architect Phone",
            "field": "architectphone"
        },
        {
            "title": "Architect Email",
            "field": "architectemail"
        },
        {
            "title": "Job Location",
            "field": "joblocation"
        },
        {
            "title": "Job Status",
            "field": "jobstatus"
        },
        {
            "title": "St Date",
            "field": "stdate"
        },
        {
            "title": "Wo Date",
            "field": "wodate"
        },
        {
            "title": "ADate",
            "field": "adate"
        },
        {
            "title": "UDate",
            "field": "udate"
        },
        {
            "title": "Link",
            "field": "link"
        }
    ];

    const editable =companies.length > 0 ?  companies.map(o => ({ ...o })): [];
    const tableHeight =(window.innerHeight - 34 - 34 - 52 - 1) / window.innerHeight * 100;
console.log("Line count is ==> ", count);
    return (
        <React.Fragment>
            <Details
                open={open}
                onSave={handleDetailsClose}
                onCancel={handleDetailsClose}
                currentRecord={currentRecord}
            />
            <Container maxWidth maxHeight>
                <Box sx={{ bgcolor: 'white', height: '100vh' }}>

            <ThemeProvider theme={defaultMaterialTheme}>

            <Table
                title="Lead Sheets"
                columns={columns}
                data={editable}
                icons={tableIcons}
                // actions={[
                //     {
                //         icon:  EditIcon,
                //         tooltip: "Edit",
                //         onClick: (event, rowData) => {
                //             setCurrentRecord(rowData);
                //             setOpen(!open);
                //             //alert("You edited company" + rowData.name);
                //         }
                //     },
                //     rowData => ({
                //         icon: DeleteIcon,
                //         tooltip: "Delete User",
                //         onClick: (event, rowData) =>
                //             new Promise((resolve, reject) => {
                //             setTimeout(async () => {
                //                 // const dataDelete = [...data];
                //                 // const index = oldData.tableData.id;
                //                 // dataDelete.splice(index, 1);
                //                 // setData([...dataDelete]);
                //                 // eslint-disable-next-line no-unused-expressions
                //                 await  firestore.delete({ collection: 'users', doc: rowData.id  }),
                //                     resolve()
                //             }, 1000)
                //         }), //eslint-disable-line no-restricted-globals
                //     })
                // ]}
                editable={{
                    onRowUpdate: (newData, oldData) =>
                        new Promise((resolve, reject) => {
                            setTimeout(async() => {
                                const itemUpdates =  {
                                   ...newData,
                                };

                                // eslint-disable-next-line no-unused-expressions
                               await firestore.update({ collection: 'mydata', doc: newData.id }, itemUpdates),
                                resolve();
                            }, 1000)
                        }),
                    onRowDelete: oldData =>
                        new Promise((resolve, reject) => {
                            setTimeout(async () => {
                                // const dataDelete = [...data];
                                // const index = oldData.tableData.id;
                                // dataDelete.splice(index, 1);
                                // setData([...dataDelete]);
                                // eslint-disable-next-line no-unused-expressions
                               await  firestore.delete({ collection: 'mydata', doc: oldData.id  }),
                                resolve()
                            }, 1000)
                        }),
                }}
                options={{
                    paginationType: "stepped",
                    pageSize: rowsPerPage,
                    sorting: false,
                    exportButton: false,
                    actionsColumnIndex: 0,
                    search: true,
                    selection: false,
                    filtering: false,
                    headerStyle: {
                        backgroundColor: '#01579b',
                        color: '#FFF'
                    },
                    cellStyle: {
                        padding: 2,
                    },
                    rowStyle: {
                        border: "1px solid green",
                        height: "30px",
                        padding: "0px !important",
                    },
                    maxBodyHeight: `${tableHeight}vh`,
                    minBodyHeight: `${tableHeight}vh`,
                    showTextRowsSelected: false,
                    pageSizeOptions: []
                }}
                components={{
                    Pagination: props => (
                        <TablePagination
                            component="div"
                            count={count}
                            page={page}
                            onPageChange={handleChangePage}
                            rowsPerPage={rowsPerPage}
                            rowsPerPageOptions={[]}
                        />
                    ),
                }}
            />
                </ThemeProvider>
                </Box>
            </Container>
        </React.Fragment>
    );
}

