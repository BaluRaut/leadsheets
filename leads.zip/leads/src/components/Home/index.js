
import * as React from 'react';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import SignOutContainer from '../../containers/SignOutContainer';
import MenuAppBar from "../../containers/HomeContainer/home";
import PropTypes from 'prop-types';
import {removeUser} from "../../actions";
/**
 *
 *     // <div>
 *     //   <h1>Home</h1>
 *     //   <p>First Name: {user.firstName}</p>
 *     //   <p>Last Name: {user.lastName}</p>
 *     //   <p>Email: {user.email}</p>
 *     //   <SignOutContainer />
 *     // </div>
 * @param user
 * @returns {JSX.Element}
 * @constructor
 */
const Home = ({ user, removeUser, firebase }) => {
  return (
      <>
          <React.Fragment>
              <CssBaseline />
              <MenuAppBar removeUser={removeUser} firebase={firebase}/>

              <Container fixed>
                  <Box sx={{ bgcolor: '#cfe8fc', height: '100vh' }} />
              </Container>
          </React.Fragment>
          </>
  );
};

Home.propTypes = {
  user: PropTypes.object.isRequired,
};

export default Home;
