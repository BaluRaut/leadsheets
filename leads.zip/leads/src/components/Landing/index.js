import React from 'react';

const Landing = () => {
  return (
    <div>
      <h1>Landing</h1>
      <p>Not Protected. Anyone can see this.</p>
    </div>
  );
};

export default Landing;
