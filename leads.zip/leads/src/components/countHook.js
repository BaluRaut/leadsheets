import { useCallback } from 'react';
import { getFirestore } from "firebase/firestore";

import {
    where,
    getCountFromServer,
    query,
    collection,
    CollectionReference,
} from 'firebase/firestore';
import firebase from "firebase/compat/app";


const tasksCollection = 'mydata';


function useFetchTasksCount(count) {

        try {
            const fbConfig = {
                databaseURL: "test22-eb7c2-default-rtdb.firebaseio.com",
                apiKey: "AIzaSyASmLWZ_68CTGBPxSxaYa_rDYrRLaKk7Vk",
                authDomain: "test22-eb7c2.firebaseapp.com",
                projectId: "test22-eb7c2",
                storageBucket: "test22-eb7c2.appspot.com",
                messagingSenderId: "220362320484",
                appId: "1:220362320484:web:958c17bb8fdd702d690d71"
            };
            const fb = firebase.initializeApp(fbConfig)
            const firestore = getFirestore(fb);

            // eslint-disable-next-line react-hooks/rules-of-hooks
            return useCallback(
                () => {

                    if(count > 0) {
                        return count;
                    }
                    const collectionRef = collection(
                        firestore,
                        tasksCollection
                    );

                    return getCountFromServer(
                        query(collectionRef)
                    );

                },
                [firestore]
            );
        } catch (e) {
            console.log("Line 37 ===> ", e);
            return 0;
        }

}

export default useFetchTasksCount;
