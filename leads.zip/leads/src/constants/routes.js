const LANDING = '/';
const SIGN_UP = '/signup';
const SIGN_IN = '/signin';
const HOME = '/home';

export { LANDING, SIGN_UP, SIGN_IN, HOME };
