import React, {Component, useState} from 'react';
import { connect } from 'react-redux';

import Home from '../../components/Home';
import {compose} from "redux";
import {removeUser} from "../../actions";
import {withFirebase} from "../../services/firebase";
import {Companies} from "../../components/Companies";
import useFetchTasksCount from "../../components/countHook";

export const HomeContainer = (props) => {
  return (<> {true && (<Companies/>)} </>)
}
