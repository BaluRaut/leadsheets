import React from "react";
import { render } from "react-dom";
import { Provider } from "react-redux";
import firebase from 'firebase/compat/app';
import "firebase/compat/firestore"; // <- needed if using firestore
import "firebase/compat/database";
import "firebase/compat/auth";
import {
    where,
    getCountFromServer,
    query,
    collection,
    CollectionReference,
} from 'firebase/firestore';
import { ReactReduxFirebaseProvider } from "react-redux-firebase";
import { createFirestoreInstance } from "redux-firestore"; // <- needed if using firestore
import createStore from "./createStore";
// Material UI initiation
import CssBaseline from "@material-ui/core/CssBaseline";
import {Companies} from "./components/Companies";
import PrimarySearchAppBar from "./components/MenuBar";
import MainApp from "./containers/MainApp";
import {setUser} from "./actions";
import {PrivateRoute} from "./routes/PrivateRoute";
import {BrowserRouter, Route, Switch} from "react-router-dom";
import {SignInContainer} from "./containers/SignInContainer";
import Routes from "./routes";
// visible components

import { getFirestore } from "firebase/firestore";
import Ft from "./services";

// const fbConfig = {
//     apiKey: 'AIzaSyCpOl6EibFPOLyhbSBpBSHqWw8hfTHO1cA',
//     authDomain: 'construction-lead-sheets.firebaseapp.com',
//     projectId: 'construction-lead-sheets'
// };
let abc;
const fbConfig = {
    databaseURL: "test22-eb7c2-default-rtdb.firebaseio.com",
    apiKey: "AIzaSyASmLWZ_68CTGBPxSxaYa_rDYrRLaKk7Vk",
    authDomain: "test22-eb7c2.firebaseapp.com",
    projectId: "test22-eb7c2",
    storageBucket: "test22-eb7c2.appspot.com",
    messagingSenderId: "220362320484",
    appId: "1:220362320484:web:958c17bb8fdd702d690d71"
};
try {
   abc = firebase.initializeApp(fbConfig);
    firebase.firestore(); // <- needed if using firestore
    window.db = getFirestore(abc);
} catch (err) {}

const styles = {
    fontFamily: "sans-serif",
    textAlign: "center"
};

const store = createStore();

const rrfProps = {
    firebase,
    config: {
        userProfile: "users"
    },
    dispatch: store.dispatch,
    createFirestoreInstance,
};

function App() {


    return (
        <Provider store={store}>
            <ReactReduxFirebaseProvider {...rrfProps}>
                <CssBaseline />
                {/*<div style={styles}>*/}
                {/*    <PrimarySearchAppBar />*/}
                {/*    <Companies />*/}
                {/*</div>*/}
                <BrowserRouter>
                    <Routes {...rrfProps}/>
                </BrowserRouter>
            </ReactReduxFirebaseProvider>
        </Provider>
    );
}

render(<App />, document.getElementById("root"));
