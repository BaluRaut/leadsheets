import { combineReducers } from "redux";
import { reducer as firebase } from "react-redux-firebase";
import {firestoreReducer as firestore} from 'redux-firestore' // <- needed if using firestore
import user from './user';


const rootReducer = combineReducers({
  user,
  firebase,
  firestore
});

export default rootReducer;
