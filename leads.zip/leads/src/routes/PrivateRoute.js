// import React from 'react';
// import {connect, useSelector} from 'react-redux';
// import {
//   BrowserRouter,
//   Switch,
//   Route,
//   Redirect
// } from 'react-router-dom';
// import { Navigate } from 'react-router-dom';
//
// import { isLoaded, isEmpty } from 'react-redux-firebase'
//
// // const PrivateRoute = ({ user, component: Component }) =>
// //   user ? <Component /> : <Navigate to={routes.SIGN_IN} replace />;
//
// export const PrivateRoute = ({ children, ...rest }) => {
//   const auth = useSelector(state => state.firebase.auth)
//   return (
//       <Route
//           {...rest}
//           render={({ location }) =>
//               isLoaded(auth) && !isEmpty(auth) ? (
//                   children
//               ) : (
//                   <Navigate
//                       to={{
//                         pathname: "/login",
//                         state: { from: location }
//                       }}
//                   />
//               )
//           }
//       />
//   );
// }
import React from 'react';
import { connect } from 'react-redux';
import { Navigate } from 'react-router-dom';
import * as routes from '../constants/routes';

const PrivateRoute = ({ user, component: Component, pr }) =>
    user ? <Component {...pr}/> : <Navigate to={routes.SIGN_IN} replace />;

const mapStateToProps = state => ({
    user: state.user,
});

export default connect(mapStateToProps)(PrivateRoute);
