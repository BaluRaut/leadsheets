const firebaseConfig = {
  databaseURL: "test22-eb7c2-default-rtdb.firebaseio.com",
  apiKey: "AIzaSyASmLWZ_68CTGBPxSxaYa_rDYrRLaKk7Vk",
  authDomain: "test22-eb7c2.firebaseapp.com",
  projectId: "test22-eb7c2",
  storageBucket: "test22-eb7c2.appspot.com",
  messagingSenderId: "220362320484",
  appId: "1:220362320484:web:958c17bb8fdd702d690d71"
};

export default firebaseConfig;
