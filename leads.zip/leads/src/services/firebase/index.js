import FirebaseContext, { withFirebase } from './context';
import Firebase from './firebase';

export { FirebaseContext, withFirebase };
export default Firebase;
