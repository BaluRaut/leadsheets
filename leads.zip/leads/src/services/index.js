
class Ft {
    constructor() {
        this.db = null;
    }

    setDb = (db) => { alert("sss"); console.log(db); this.db = db;}
    getDb = () => {  console.log("Line 8, ", this); return this.db; }
}

export default Ft;
